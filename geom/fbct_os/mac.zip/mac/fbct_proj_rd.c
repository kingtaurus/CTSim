#include "fbct_proj.h"

bool fbct_proj_rd( const GEOM_PARAM geom, cfloat *image, float *proj ){
	
	cint nx = geom.nx;
	cint ny = geom.ny;
	cfloat dx = geom.dx;
	cfloat dy = geom.dy;
	
	cint nu = geom.nu;
	cfloat du = geom.du;
	cfloat wu = ( - ( nu - 1.0 ) / 2.0 + geom.offset_u ) * du;
	
	cfloat sad = geom.sad;
	cfloat add = geom.add;
	cfloat sdd = geom.sdd;
	
	cfloat noviews = geom.noviews;
	
	cfloat delta = dx / 2.0 ;
	
	cfloat cubemin_x = ( - ( nx - 1.0 ) / 2.0 + geom.offset_x ) * dx;
	cfloat cubemax_x = ( + ( nx - 1.0 ) / 2.0 + geom.offset_x ) * dx;
	cfloat cubemin_y = ( - ( ny - 1.0 ) / 2.0 + geom.offset_y ) * dy;
	cfloat cubemax_y = ( + ( ny - 1.0 ) / 2.0 + geom.offset_y ) * dy;
	
	for ( int ib = 0 ; ib < noviews; ib ++ ) {
		
		double beta = geom.betas[ib];		
		float sin_a = (float) sin( beta );
		float cos_a = (float) cos( beta );
		
		float source_x = - sad * sin_a;
		float source_y = - sad * cos_a;
		
		for ( int iu = 0 ; iu < nu ; iu++ ) {
			
			double phi = beta + atan( (double)(( iu * du + wu ) / sdd ) );
			
			float raydir_x = (float) sin( phi );
			float raydir_y = (float) cos( phi );
			
			// find the enter and leave point of ray
			float tn = - 1E10;
			float tf = + 1E10;
			
			if ( raydir_x < -1E-12 && raydir_x > 1E-12 ) {
				if ( source_x < cubemin_x || source_x > cubemax_x ) {
					continue;
				}
			}
			else {
				
				float t1 = ( cubemin_x - source_x ) / raydir_x ;
				float t2 = ( cubemax_x - source_x ) / raydir_x ;
				
				if ( t1 > t2 ) {
					float ttmp = t1;
					t1 = t2;
					t2 = ttmp;
				}
				
				if (t1 > tn ){
					tn = t1;
				}
				
				if ( t2 < tf ){
					tf = t2;
				}
				
				if (tn > tf || tf < 0 ) {
					continue;
				}
				
			}
			
			
			if ( raydir_y < -1E-12 && raydir_y > 1E-12  ) {
				if ( source_y < cubemin_y || source_y > cubemax_y ) {
					continue;
				}
			}
			else {
				float t1 = (cubemin_y - source_y ) / raydir_y ;
				float t2 = (cubemax_y - source_y ) / raydir_y ;
				
				if ( t1 > t2 ) {
					float ttmp = t1;
					t1 = t2;
					t2 = ttmp;
				}
				
				if (t1 > tn ){
					tn = t1;
				}
				
				if ( t2 < tf ){
					tf = t2;
				}
				
				if (tn > tf || tf < 0 ) {
					continue;
				}
			}
			
			float temp = 0;
			float x, y, wxl, wyl, t;
			int ix, iy;
			
			// go along the x-ray
			for ( t = tn ; t < tf ; t = t + delta) {
				
				x = ( source_x + t * raydir_x - cubemin_x ) / dx ;
				y = ( source_y + t * raydir_y - cubemin_y ) / dy ;
				
				
				ix = floorf( x );
				iy = floorf( y );
				
				if( ix > 0 && ix < nx - 1 && iy > 0 &&  iy < ny - 1 ){
					
					wxl = x - ix;
					wyl = y - iy;
					
					//bilinear interpolation
					temp = temp + (1-wyl) * ( (1-wxl) * image[iy*nx+ix] + wxl * image[iy*nx+ix+1]) + wyl * ( (1-wxl) * image[iy*nx+nx+ix] + wxl * image[iy*nx+nx+ix+1] ) ;
					
				}
			}
			
			proj[ib * nu + iu ] = temp * delta / 10;
			
		}
		
	}
	
	return true;
}

