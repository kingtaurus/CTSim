#include "fbct_proj.h"

#define IS_FLAT_DETECTOR 1

bool fbct_proj_dd( const GEOM_PARAM geom, cfloat *image, float *proj ){
	
	cint nx = geom.nx;
	cint ny = geom.ny;
	cfloat dx = geom.dx;
	cfloat dy = geom.dy;
	cfloat wx = - ( nx - 1.0 ) / 2.0 + geom.offset_x;
	cfloat wy = - ( ny - 1.0 ) / 2.0 + geom.offset_y;
	
	cint nu = geom.nu;
	cfloat du = geom.du;
	cfloat wu = - ( nu - 1.0 ) / 2.0 + geom.offset_u;
	
	cfloat sad = geom.sad;
	//cfloat add = geom.add;
	cfloat sdd = geom.sdd;
	
	cfloat sdd_du = sdd / du;
	
	
	cfloat noviews = geom.noviews;
	
	for ( int ib = 0; ib < noviews ; ib++) {
		
		double beta = geom.betas[ib];		
		float sin_a = (float) sin( beta );
		float cos_a = (float) cos( beta );
		
		float dx_sin_2 = dx * sin_a / 2.0;
		float dx_cos_2 = dx * cos_a / 2.0;
		float dy_sin_2 = dy * sin_a / 2.0;
		float n_dy_cos_2 = - dy * cos_a / 2.0;
		
		float xc, yc, tproj0, dsxy0, tproj0_dsxy0;
		float cos_gamma, sin_gamma, cos_phi, sin_phi, amplitude;
		float umin, umax;
		int iumin, iumax;
		
		
		for ( int iy = 0; iy < ny ; iy ++ ) {
			
			for (int ix = 0; ix < nx ; ix++ ) {

				xc = ( ix + wx ) * dx;
				yc = ( iy + wy ) * dy;
				
				tproj0 = xc * cos_a - yc * sin_a ;
				dsxy0  = sad + xc * sin_a + yc * cos_a ;
				tproj0_dsxy0 = sqrt( tproj0 * tproj0 + dsxy0 * dsxy0 );
				
				cos_gamma = dsxy0 / tproj0_dsxy0;
				sin_gamma = tproj0 / tproj0_dsxy0 ;
				
				cos_phi = fabs( cos_a * cos_gamma - sin_a * sin_gamma );
				sin_phi = fabs( sin_a * cos_gamma + cos_a * sin_gamma );
				
				// compute amplitude function and footprint boundaries
				
#if IS_FLAT_DETECTOR
				if ( cos_phi > sin_phi) {
					
					amplitude = dx / cos_phi / 10.0;
					umin = sdd_du * ( tproj0 + dx_cos_2 ) / ( dsxy0 + dx_sin_2 ) - wu;
					umax = sdd_du * ( tproj0 - dx_cos_2 ) / ( dsxy0 - dx_sin_2 ) - wu;
					
				} else {
					
					amplitude = dx / sin_phi / 10.0;
					umin = sdd_du * ( tproj0 + dy_sin_2 ) / ( dsxy0 + n_dy_cos_2 ) - wu;
					umax = sdd_du * ( tproj0 - dy_sin_2 ) / ( dsxy0 - n_dy_cos_2 ) - wu;
					
				}
#else
				if ( cos_phi > sin_phi) {
					
					amplitude = dx / cos_phi / 10.0;
					umin = sdd_du * atan(( tproj0 + dx_cos_2 ) / ( dsxy0 + dx_sin_2 )) - wu;
					umax = sdd_du * atan(( tproj0 - dx_cos_2 ) / ( dsxy0 - dx_sin_2 )) - wu;
					
				} else {
					
					amplitude = dx / sin_phi / 10.0;
					umin = sdd_du * atan(( tproj0 + dy_sin_2 ) / ( dsxy0 + n_dy_cos_2 )) - wu;
					umax = sdd_du * atan(( tproj0 - dy_sin_2 ) / ( dsxy0 - n_dy_cos_2 )) - wu;
					
				}
				
#endif
				
				if ( umin >= umax ) {
					float temp = umax;
					umax = umin;
					umin = temp;
				}
				
				// decide if it outside the detector
				umin = max( umin + 0.5, 0  );
				umax = min( umax + 0.5, nu );
				
				if ( umin > umax ){
					continue;
				}
				
				iumin = floorf( umin );
				iumax = floorf( umax );
				iumax = min( iumax, nu-1 );
				
				// projection
				if (iumin == iumax) {
					
					proj[ib * nu + iumin ] = proj[ib * nu + iumin ] + amplitude * (umax-umin) * image[ iy*nx+ix];
					
				}
				else{
										
					for ( int iu = iumin ; iu <= iumax ; iu++) {
						
						if ( iu == iumin ) {
							proj[ib * nu + iu ] = proj[ib * nu + iu ] + amplitude * (iumin+1.0-umin) * image[iy*nx+ix];
						} else if (iu == iumax) {
							proj[ib * nu + iu ] = proj[ib * nu + iu ] + amplitude * (umax-iumax) * image[iy*nx+ix];
						} else {
							proj[ib * nu + iu ] = proj[ib * nu + iu ] + amplitude * image[iy*nx+ix];
						}
						
					} //iu

				}
				
			} //ix
			
		} //iy
		
	} //ib
	
	return true;
}

