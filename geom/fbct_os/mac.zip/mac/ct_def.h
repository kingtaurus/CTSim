#include "math.h"

#ifndef _CT_DEF_H_
#define _CT_DEF_H_

#define Debug1 0
#define Debug3 0

typedef const int cint;
typedef const float cfloat;
typedef const double cdouble;

typedef enum { PROJ_RD, PROJ_DD, PROJ_TF, BACK_PD, BACK_DD, BACK_TF }  GEOM_TYPE ;

typedef struct{
	unsigned int nx;
	unsigned int ny;
	unsigned int nz;
	float dx;
	float dy;
	float dz;
	float offset_x;
	float offset_y;
	float offset_z;
	unsigned int nu;
	unsigned int nv;
	float du;
	float dv;
	float offset_u;
	float offset_v;
	float sad;
	float add;
	float sdd;
	unsigned int noviews;
	double *betas;
} GEOM_PARAM;


#define sqr(x) (x * x)

#ifndef max
#define max( a, b ) ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min( a, b ) ( ((a) < (b)) ? (a) : (b) )
#endif



#endif