#include "ct_def.h"

#ifndef _FBCT_BACK_H_
#define _FBCT_BACK_H_

bool fbct_back_pd( const GEOM_PARAM geom, float *image, cfloat *proj );

bool fbct_back_dd( const GEOM_PARAM geom, float *image, cfloat *proj );

bool fbct_back_tf( const GEOM_PARAM geom, float *image, cfloat *proj );



#endif