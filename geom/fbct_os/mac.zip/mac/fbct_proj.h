#include "ct_def.h"

#ifndef _FBCT_PROJ_H_
#define _FBCT_PROJ_H_

bool fbct_proj_rd( const GEOM_PARAM geom, cfloat *image, float *proj );

bool fbct_proj_dd( const GEOM_PARAM geom, cfloat *image, float *proj );

bool fbct_proj_tf( const GEOM_PARAM geom, cfloat *image, float *proj );




#endif