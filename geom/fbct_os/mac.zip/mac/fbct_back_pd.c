#include "fbct_back.h"

bool fbct_back_pd( const GEOM_PARAM geom, float *image, cfloat *proj ){
	cint nx = geom.nx;
	cint ny = geom.ny;
	cfloat dx = geom.dx;
	cfloat dy = geom.dy;
	cfloat wx = - ( nx - 1.0 ) / 2.0 + geom.offset_x;
	cfloat wy = - ( ny - 1.0 ) / 2.0 + geom.offset_y;
	
	cint nu = geom.nu;
	cfloat du = geom.du;
	cfloat wu = - ( nu - 1.0 ) / 2.0 + geom.offset_u;
	
	cfloat sad = geom.sad;
	//cfloat add = geom.add;
	cfloat sdd = geom.sdd;
	
	cfloat noviews = geom.noviews;
	
	float xc, yc, xRot, yRot;
	float w2, u, wul;
	int iu;
	
	for ( int ib = 0; ib < noviews ; ib++) {
		
		double beta = geom.betas[ib];		
		float sin_a = (float) sin( beta );
		float cos_a = (float) cos( beta );
		
		for (int ix = 0; ix < nx ; ix++ ) {
			
			for ( int iy = 0; iy < ny ; iy ++ ) {
				
				xc = ( ix + wx ) * dx;
				yc = ( iy + wy ) * dy;
				
				xRot = xc * cos_a - yc * sin_a ;
				yRot = xc * sin_a + yc * cos_a ;
				
				
				w2 = sdd / ( sad + yRot );
				
				u = xRot * w2 / du - wu;
				
				if ( u < 1E-6 || u > nu - 1 - 1E-6 ) {
					continue;
				}
				
				iu = floorf( u );
				wul = u - iu;

				image[iy*nx+ix] = image[iy*nx+ix] + w2 * w2 * ( (1-wul) * proj[ib*nu+iu] + wul * proj[ib*nu+iu+1] );
				
			} //ix
			
		} //iy
		
	} //ib
	
	return true;
}