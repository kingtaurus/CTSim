#include "fbct_back.h"

#define IS_FLAT_DETECTOR 1

bool fbct_back_tf( const GEOM_PARAM geom, float *image, cfloat *proj ){

	cint nx = geom.nx;
	cint ny = geom.ny;
	cfloat dx = geom.dx;
	cfloat dy = geom.dy;
	cfloat wx = - ( nx - 1.0 ) / 2.0 + geom.offset_x;
	cfloat wy = - ( ny - 1.0 ) / 2.0 + geom.offset_y;
	
	cint nu = geom.nu;
	cfloat du = geom.du;
	cfloat wu = - ( nu - 1.0 ) / 2.0 + geom.offset_u;
	
	cfloat sad = geom.sad;
	//cfloat add = geom.add;
	cfloat sdd = geom.sdd;
	
	cfloat sdd_du = sdd / du;
	
	
	cfloat noviews = geom.noviews;
	
	for ( int ib = 0; ib < noviews ; ib++) {
		
		double beta = geom.betas[ib];		
		float sin_a = (float) sin( beta );
		float cos_a = (float) cos( beta );
		
		float dx_sin_2 = dx * sin_a / 2.0;
		float dx_cos_2 = dx * cos_a / 2.0;
		float dy_sin_2 = dy * sin_a / 2.0;
		float n_dy_cos_2 = - dy * cos_a / 2.0;
		
		float xc, yc, tproj0, dsxy0, tproj0_dsxy0;
		float cos_gamma, sin_gamma, cos_phi, sin_phi, amplitude;
		float tau[4];
		int iumin, iumax;
		float bl, br, xl, xr;
		
		for (int ix = 0; ix < nx ; ix++ ) {
			
			for ( int iy = 0; iy < ny ; iy ++ ) {
				
				
				xc = ( ix + wx ) * dx;
				yc = ( iy + wy ) * dy;
				
				tproj0 = xc * cos_a - yc * sin_a ;
				dsxy0  = sad + xc * sin_a + yc * cos_a ;
				tproj0_dsxy0 = sqrt( tproj0 * tproj0 + dsxy0 * dsxy0 );
				
				cos_gamma = dsxy0 / tproj0_dsxy0;
				sin_gamma = tproj0 / tproj0_dsxy0 ;
				
				cos_phi = fabs( cos_a * cos_gamma - sin_a * sin_gamma );
				sin_phi = fabs( sin_a * cos_gamma + cos_a * sin_gamma );
				
				// compute amplitude function and footprint boundaries
				if ( cos_phi > sin_phi) {
					amplitude = dx / cos_phi / 10.0;
				} else {
					amplitude = dx / sin_phi / 10.0;
				}
				
				
#if IS_FLAT_DETECTOR
				
				tau[0] = sdd_du * ( tproj0 + dx_cos_2 + dy_sin_2 ) / ( dsxy0 + dx_sin_2 + n_dy_cos_2 ) - wu;
				tau[1] = sdd_du * ( tproj0 - dx_cos_2 + dy_sin_2 ) / ( dsxy0 - dx_sin_2 + n_dy_cos_2 ) - wu;
				tau[2] = sdd_du * ( tproj0 + dx_cos_2 - dy_sin_2 ) / ( dsxy0 + dx_sin_2 - n_dy_cos_2 ) - wu;
				tau[3] = sdd_du * ( tproj0 - dx_cos_2 - dy_sin_2 ) / ( dsxy0 - dx_sin_2 - n_dy_cos_2 ) - wu;
				
#else
				
				tau[0] = sdd_du * atan(( tproj0 + dx_cos_2 + dy_sin_2 ) / ( dsxy0 + dx_sin_2 + n_dy_cos_2 )) - wu;
				tau[1] = sdd_du * atan(( tproj0 - dx_cos_2 + dy_sin_2 ) / ( dsxy0 - dx_sin_2 + n_dy_cos_2 )) - wu;
				tau[2] = sdd_du * atan(( tproj0 + dx_cos_2 - dy_sin_2 ) / ( dsxy0 + dx_sin_2 - n_dy_cos_2 )) - wu;
				tau[3] = sdd_du * atan(( tproj0 - dx_cos_2 - dy_sin_2 ) / ( dsxy0 - dx_sin_2 - n_dy_cos_2 )) - wu;
				
#endif
				
				//sort taus
				if (tau[0] > tau[1]) {
					float temp = tau[0];
					tau[0] = tau[1];
					tau[1] = temp;
				}
				
				
				if (tau[2] > tau[3]) {
					float temp = tau[2];
					tau[2] = tau[3];
					tau[3] = temp;
				}
				
				if (tau[0] > tau[2]) {
					float temp = tau[0];
					tau[0] = tau[2];
					tau[2] = temp;
				}
				
				
				if (tau[1] > tau[3]) {
					float temp = tau[1];
					tau[1] = tau[3];
					tau[3] = temp;
				}
				
				if (tau[1] > tau[2]) {
					float temp = tau[1];
					tau[1] = tau[2];
					tau[2] = temp;
				}
				
				// boundaries
				iumin = max( floorf(tau[0] + 0.5), 0 );
				iumax = min( ceilf(tau[3] + 0.5), nu - 1);
				
				if (iumin > iumax) {
					continue;
				}

				float temp = 0.0;
				
				for ( int iu = iumin ; iu <= iumax ; iu++) {
					
					float weight = 0.0;
					bl = iu - 0.5;
					br = iu + 0.5;
					
					//left piece
					xl = max(bl, tau[0]);
					xr = min(br, tau[1]);
					if (xr > xl) {
						weight = weight + (( (xr-tau[0]) * (xr-tau[0]) - (xl-tau[0]) * (xl-tau[0]) ) / (tau[1] - tau[0])) /2;
					}
					
					//middle piece
					xl = max(bl, tau[1]);
					xr = min(br, tau[2]);
					if (xr > xl) {
						weight = weight + ( xr - xl );
					}
					
					//right piece
					xl = max(bl, tau[2]);
					xr = min(br, tau[3]);
					if (xr > xl) {
						weight = weight + (( (xl-tau[3]) * (xl-tau[3]) - (xr-tau[3]) * (xr-tau[3]) ) / (tau[3] - tau[2])) /2;
					}
					
					temp = temp + amplitude * weight * proj[ib * nu + iu ];
					
				} //iu
				
				
				image[iy*nx+ix] = image[iy*nx+ix] + temp;
				
			} //ix
			
		} //iy
		
	} //ib
	
	
	
	return true;
}